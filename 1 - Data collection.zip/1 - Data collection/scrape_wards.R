library(rvest)
library(glue)
library(stringr)
library(purrr)

library(dplyr)
library(tidyr)

library(openxlsx)


get_boro_wards <- function(boro, nxt) {
    dat %>%
        html_elements(xpath = glue(paste0("//h3[span[.='{boro}']]/", 
                                     "following-sibling::*[following-sibling::", 
                                     "h3[span[.='{nxt}']]]")))  %>%
        get_wards() %>%
            dplyr::mutate(bor = boro)
}



get_wards <- function(xx) {
    active_time <- ""
    latest <- FALSE
    map_df(xx, function(xy) {
        li_itms <- xy %>% 
            html_elements("li")
        txt <- xy %>% html_text2()
        if(nchar(txt) > 0 & str_detect(txt, "Wards from")) {
            active_time <<- txt # NOT IDEAL
            latest <<- str_detect(txt, "Wards from \\d+ \\w+ \\d+(:| to present)")
        }
        if(length(li_itms) > 0) {
            data.frame(itms = li_itms %>% html_text(), tm = active_time, 
                       lt = latest, stringsAsFactors = FALSE)
            
        } else {
            data.frame()
        }
        
    }) 
}


pg <- "https://en.wikipedia.org/wiki/List_of_electoral_wards_in_Greater_London"

dat <- read_html(pg) %>%
    html_elements(".mw-parser-output")

x <- dat %>% 
    html_elements("h3 .mw-headline") %>%
    html_text2()

all <- map_df(1:32, function(i) {
    get_boro_wards(x[i], x[i + 1])
})


ptn <- "(.*)\\((\\d)\\)"
dat <- all %>%
    filter(lt == TRUE) %>%
    mutate(ward = trimws( str_replace(itms, ptn, "\\1"))) %>%
    mutate(num = as.numeric(str_replace(itms, ptn, "\\2"))) %>%
    select(ward, num, borough = bor)

    
for(br in unique(dat$borough)) {
    print(glue("Doing {br}"))
    wb <- loadWorkbook("borough_template.xlsx")
    bdat <- dat %>% filter(borough == br)
    sheets <- c()

    for(i in 1:nrow(bdat)) {
        sheetnm <- str_trunc(bdat$ward[i], 14, side = "right")
        
        if(sheetnm %in% sheets) {
            sheetnm <- str_trunc(bdat$ward[i], 19, side = "right")
        } 
        sheets <- c(sheets, sheetnm)
        
        cloneWorksheet(wb, sheetnm, "1")
        writeData(wb, sheetnm, br, startCol = 1, startRow = 3)
        writeData(wb, sheetnm, c(bdat$ward[i], bdat$num[i]), 
                  startCol = 8, startRow = 5)
        showGridLines(wb, sheetnm, FALSE)
    }
    
    removeWorksheet(wb, 1)
    activeSheet(wb) <- 1
    saveWorkbook(wb, glue("Ward Forms/{br} local results form.xlsx"), overwrite = TRUE)
}

